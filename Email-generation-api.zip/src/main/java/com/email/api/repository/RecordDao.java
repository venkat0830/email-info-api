//package com.email.api.repository;
//
//import java.util.List;
//
//import com.email.api.model.EmailDetails;
//
//public interface RecordDao {
//
//	List<EmailDetails> getEmailDetails(String frequency) throws Exception;
//
//	Integer getRecordDetails(String providerTin, String recordType, String frequency) throws Exception;
//}
