//package com.email.api.service;
//
//import java.util.List;
//import java.util.Map;
//
//import com.email.api.model.AuditEmailDetails;
//import com.email.api.model.BoTable;
//import com.email.api.model.EmailDetails;
//
//public interface EmailService {
//
//	void sendDailyEmail(String emailAdd) throws Exception;
//	//void sendWeeklyEmail()throws Exception;
//	
//	EmailDetails getProviderDetails(String corporateTaxID, String providerTin, String uuID);
//	List<AuditEmailDetails> getAuditEmailDetails(String emailAddress, String providerTin, String uuID);
//	Map<String, Integer> getAuditSummary(String emailAddress, String providerTin, String uuID);
//}
