package com.email.api.model;

public class BoTable {
	
	String maintanencePage;
	String emailReg;
	String hpc;
	String mrm;
	String smart;
	String recon;
	String pend;
	public String getMaintanencePage() {
		return maintanencePage;
	}
	public void setMaintanencePage(String maintanencePage) {
		this.maintanencePage = maintanencePage;
	}
	public String getEmailReg() {
		return emailReg;
	}
	public void setEmailReg(String emailReg) {
		this.emailReg = emailReg;
	}
	public String getHpc() {
		return hpc;
	}
	public void setHpc(String hpc) {
		this.hpc = hpc;
	}
	public String getMrm() {
		return mrm;
	}
	public void setMrm(String mrm) {
		this.mrm = mrm;
	}
	public String getSmart() {
		return smart;
	}
	public void setSmart(String smart) {
		this.smart = smart;
	}
	public String getRecon() {
		return recon;
	}
	public void setRecon(String recon) {
		this.recon = recon;
	}
	public String getPend() {
		return pend;
	}
	public void setPend(String pend) {
		this.pend = pend;
	}
	
	

}
