//package com.email.api;
//
//import java.text.DateFormat;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.time.Instant;
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.ZoneId;
//import java.time.ZonedDateTime;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.Locale;
//import java.util.TimeZone;
//
//import org.joda.time.DateTimeZone;
//
//import com.email.api.utilities.Constants;
//
//import cucumber.api.java.sk.Atiež;
//
//public class Test {
////
//	private static final String DATE = "yyyy-MM-dd HH:mm:ss";
//
////	private static final String SMARTEDIT_DATE = "MM/dd/yyyy";`
////
//	public static void main(String[] args) throws Exception {
////		TimeZone timeZone = TimeZone.getTimeZone("GMT-5");
//		SimpleDateFormat sdf = new SimpleDateFormat(DATE, Locale.US);
////		sdf.setTimeZone(TimeZone.getTimeZone("CST6CDT"));
//		Date date = new Date(Long.valueOf("1588503600292"));
//		System.out.println("Date:------->" + sdf.parse(sdf.format(date)));
//
//	}
//}
