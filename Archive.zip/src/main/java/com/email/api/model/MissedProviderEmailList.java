package com.email.api.model;

import java.util.List;

public class MissedProviderEmailList {
	
	private List<MissedProvider> missedProviderEmailList;

	public List<MissedProvider> getMissedProviderEmailList() {
		return missedProviderEmailList;
	}

	public void setMissedProviderEmailList(List<MissedProvider> missedProviderEmailList) {
		this.missedProviderEmailList = missedProviderEmailList;
	}
	
	

}
