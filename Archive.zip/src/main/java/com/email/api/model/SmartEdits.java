package com.email.api.model;

import java.util.List;

public class SmartEdits {
	
	private List<Notification> notificationList;

	public List<Notification> getNotificationList() {
		return notificationList;
	}

	public void setNotificationList(List<Notification> notificationList) {
		this.notificationList = notificationList;
	}
	
}
