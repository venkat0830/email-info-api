package com.email.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailNotifyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailNotifyApiApplication.class, args);
	}

}
