package com.email.api;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
